#ifndef __HW_UART4_debugPC_H
#define __HW_UART4_debugPC_H

#define GIMBAL_RECVBUF_SIZE  11
#define SEND_MAX_SIZE 11+4+1

void UART4_Configuration(void);

#endif //__HW_UART4_debugPC_H
