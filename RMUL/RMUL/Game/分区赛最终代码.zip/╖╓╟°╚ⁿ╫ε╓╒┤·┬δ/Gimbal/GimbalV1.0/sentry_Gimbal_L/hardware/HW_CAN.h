#ifndef __BSP_CAN_H
#define __BSP_CAN_H

void CAN_Configuration(void);

#endif //__BSP_CAN_H
