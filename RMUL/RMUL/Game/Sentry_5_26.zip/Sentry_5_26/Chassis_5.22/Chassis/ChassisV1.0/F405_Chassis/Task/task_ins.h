#ifndef _TASK_INS_H
#define _TASK_INS_H


void ins_task(void *pvParameters);

extern IMU IMUReceive;
extern IMU_Data_t IMUData;

#endif // 
