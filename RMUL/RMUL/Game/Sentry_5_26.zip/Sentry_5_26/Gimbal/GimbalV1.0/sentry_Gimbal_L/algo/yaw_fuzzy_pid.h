#ifndef _YAW_FUZZY_PID_H
#define _YAW_FUZZY_PID_H



#include "main.h"





float Yaw_FuzzyPID_Calc(Fuzzy_Typedef *pid,float ActualValue);


#endif
