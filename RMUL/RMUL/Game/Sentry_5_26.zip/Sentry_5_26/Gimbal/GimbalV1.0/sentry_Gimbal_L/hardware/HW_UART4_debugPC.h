#ifndef __HW_UART4_debugPC_H
#define __HW_UART4_debugPC_H

#define GimbalBufBiggestSize  8
#define SEND_MAX_SIZE 8

void UART4_Configuration(void);

#endif //__HW_UART4_debugPC_H
