#ifndef _JUMPCAL_TASK_H_
#define _JUMPCAL_TASK_H_

void JumpCal_task(void );
#define USING_JUDGE_EQUIPMENT   1
#define MAX_BUFFERING_ENERGY    60
#endif
