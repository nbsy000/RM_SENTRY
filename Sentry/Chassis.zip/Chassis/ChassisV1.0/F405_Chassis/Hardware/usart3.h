#ifndef __USART3_H__
#define __USART3_H__
#define RX_USART3_BUFFER 30

void USART3_Configuration(void);
void RC_Rst(void);
#endif

